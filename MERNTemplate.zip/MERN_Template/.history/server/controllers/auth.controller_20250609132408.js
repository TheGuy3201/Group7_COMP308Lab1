import User from '../models/user.model.js'
import config from './../../config/config.js'
const signin = (req, res) => { 


}
const signout = (req, res) => { 


}
const requireSignin = ‘’
const hasAuthorization = (req, res) => { 

    
 }
export default { signin, signout, requireSignin, hasAuthorization }

